document.addEventListener("DOMContentLoaded", function() {
    alert("স্বাগতম আমার পোর্টফোলিও ওয়েবসাইটে!");
});
